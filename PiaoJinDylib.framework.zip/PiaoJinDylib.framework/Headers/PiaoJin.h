//
//  PiaoJin.h
//  PiaoJinDylib
//
//  Created by 飘金 on 2017/8/10.
//  Copyright © 2017年 cn.mjbang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PiaoJin : NSObject

- (void)love;

@end
